package rf.gd.tekporconsult.hiom.hiom;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
