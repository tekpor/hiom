import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Notifications extends StatefulWidget {
  const Notifications({Key? key}) : super(key: key);

  @override
  _NotificationsState createState() => _NotificationsState();
}
late FirebaseFirestore firestore;
late String uid;
bool get = true;
class _NotificationsState extends State<Notifications> {
  var currentUser = FirebaseAuth.instance.currentUser;

  var j = 0;



  @override
  void initState() {
    // TODO: implement init
    //  State
    super.initState();
    firestore = FirebaseFirestore.instance;

  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    j = 0;
  }

  @override
  Widget build(BuildContext context) {


    final Stream<QuerySnapshot> _usersStream = FirebaseFirestore.instance.collection('notification').snapshots();




    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.lightBlue, title: const Center(child: Text('MY NOTIFICATION',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 30),)),),
      body: currentUser == null? const Center(child: CircularProgressIndicator(color: Colors.red,)) : StreamBuilder<QuerySnapshot>(
        stream: _usersStream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text('Something went wrong'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: Text("Loading"));
          }
                return ListView(
            children: snapshot.data!.docs.map((DocumentSnapshot document) {
              Map<String, dynamic> data = document.data()! as Map<String, dynamic>;
              return  data['to'].toString() == currentUser!.uid  || data['to'].toString() == 'general'?Padding(
                padding:  const EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                        color: Colors.blue
                  ),
                  child:  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GestureDetector(
                      onTap: (){
                        if(data['link'] != null){
                          Navigator.of(context).pushNamed('/explorereview',arguments: {
                            'image':data['image'].toString(),
                            'text':data['message'].toString()
                          });
                        }
                      },
                      child: ListTile(
                        selected: true,
                        title: Text(data['name'],style: const TextStyle(fontSize: 23,fontWeight: FontWeight.bold,color: Colors.black87),),
                        subtitle: Padding(
                          padding: const EdgeInsets.all(1.0),
                          child: Text(data['message'], maxLines: 5,style: const TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white),),
                        ),
                      ),
                    ),
                  ),
                ),
              ):const Text('');
            }).toList(),
          );
        },
      ),
    );
  }

  void getData(String uid) {


  }
}
