import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  _RegisterState createState() => _RegisterState();
}
var _chosenValue,hospitalid,app;
String error = 'Enter Your Hospital Credentials here!';
late FirebaseFirestore firestore;
late FirebaseAuth auth;
List<String> temp = [];
bool get = true;
class _RegisterState extends State<Register> {
  var j = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializeDefault();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    j = 0;
    error = 'Enter Your Hospital Credentials here!';
  }

  @override
  Widget build(BuildContext context) {
    if(app != null){
      auth.authStateChanges().listen((User? user) {
        if (user != null) {
          if(get){
            Navigator.of(context).pushReplacementNamed('/dashboard');
            get = false;
          }
        }
      });
    }


    final AlertDialog withUs = AlertDialog(
      contentPadding: EdgeInsets.zero,
      content: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 50,
          height: 100,
          child:Column(
            children: const [
              CircularProgressIndicator(color: Colors.red,),
              Text("Processing... please wait!")
            ],
          ),
        ),
      ),
    );

    getData();


    return WillPopScope(
      onWillPop: () async{
        if(j > 2){
          return true;
        }else{
          j++;
          return false;
        }
      },
      child: Scaffold(
        body: app ==null && temp.isEmpty?const Center(child: CircularProgressIndicator(color: Colors.redAccent,)): ListView(
          children: [

            Padding(
              padding: const EdgeInsets.only(top: 15),
              child: Center(child: Image.asset(
                'images/logo.png', width: 200, height: 200,)),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 30),
              child: Center(child: Text('HIOM', style: TextStyle(fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),)),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 35,bottom: 10,top:8),
              child: Row(
                children: [
                  const Icon(Icons.help_outline,color: Colors.red,),
                  Padding(
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Text(error, style: const TextStyle(fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.red),),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 25),
              child: Center(
                child: Container(
                  height: 50,
                  width: MediaQuery
                      .of(context)
                      .size
                      .width - 70,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.white10
                  ),
                  child: Center(
                    child: Container(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width - 70,
                      height: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(13),
                          color: Colors.white10
                      ),
                      child: TextField(
                        onChanged: (value){
                          _chosenValue = value;
                        },decoration: const InputDecoration(
                        labelText: "Name Of Hospital Affiliation",
                        border: OutlineInputBorder(),
                        helperStyle: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.normal,
                            color: Colors.blue,
                            fontSize: 15),
                        labelStyle: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.normal,
                            color: Colors.blue,
                            fontSize: 15),
                        hintText: 'Enter Name Of Hospital Affiliation',
                        hintStyle: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.normal,
                            color: Colors.blue,
                            fontSize: 20),
                      ),),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Container(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width - 70,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(13),
                      color: Colors.white10
                  ),
                  child: TextField(
                    onChanged: (value){
hospitalid = value;
                    },decoration: const InputDecoration(
                    labelText: "Customize Hospital ID",
                    border: OutlineInputBorder(),
                    helperStyle: TextStyle(fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.normal,
                        color: Colors.blue,
                        fontSize: 15),
                    labelStyle: TextStyle(fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.normal,
                        color: Colors.blue,
                        fontSize: 15),
                    hintText: 'Enter Your Own Hospital ID',
                    hintStyle: TextStyle(fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.normal,
                        color: Colors.blue,
                        fontSize: 20),
                  ),),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 20, bottom: 25),
              child: Center(child: Text('Forgot Hospital ID?', style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 18,
                  fontStyle: FontStyle.italic,
                  color: Colors.black54),)),
            ),
            GestureDetector(
              onTap: () async {
                showDialog<void>(context: context, builder: (context) => withUs);
                if(_chosenValue != null && hospitalid != null){
                  try {
                   await auth.createUserWithEmailAndPassword(
                        email: "${hospitalid.toString().trim()}@gmail.com",
                        password: _chosenValue.toString().trim()
                    ).then((value) => {
                      Navigator.pop(context),
                      Navigator.of(context).pushReplacementNamed('/dashboard'),
                    });
                  } on FirebaseAuthException catch (e) {
                    if (e.code == 'weak-password') {
                      Navigator.pop(context);
                      setState(() {
                        error = 'The Hospital ID provided is not valid.';
                      });
                    } else if (e.code == 'email-already-in-use') {
                      Navigator.pop(context);
                      setState(() {
                        error = 'The account already exists for that Hospital ID.';
                      });
                    }
                  } catch (e) {
                Navigator.pop(context);
                    error = e.toString();
                  }
                }else{
                  Navigator.pop(context);
                  setState(() {
                    error = 'Some required information is missing!';
                  });
                }

              },
              child: Padding(
                padding: const EdgeInsets.only(bottom: 80),
                child: Center(
                  child: Container(
                    width: 200,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      color: Colors.blue,
                    ),
                    child: const Center(child: Text('Register',
                      style: TextStyle(fontSize: 23, fontWeight: FontWeight
                          .bold, color: Colors.black),)),
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Center(child: Text('Already have a Hospital ID?',
                style: TextStyle(fontWeight: FontWeight.normal,
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                    color: Colors.black54),)),
            ),
            GestureDetector(
              onTap: (){
                Navigator.of(context).pushReplacementNamed('/');
              },
              child: const Center(child: Text('Login with Hospital ID.',
                style: TextStyle(fontWeight: FontWeight.normal,
                    fontSize: 20,
                    fontStyle: FontStyle.normal,
                    color: Colors.blue),)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> initializeDefault() async {
    app = await Firebase.initializeApp().then((value) => {
    setState(() {
    }),
    });
    auth = FirebaseAuth.instance;
    firestore = FirebaseFirestore.instance;
    print('Initialized default app $app');

  }

  void getData() async {
    FirebaseFirestore.instance
        .collection('hospitals')
        .limit(1)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        setState(() {
          temp = List<String>.from(doc['hospitals'] as List);
        });
      });
    });
  }
}