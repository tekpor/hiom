import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hiom/register/views.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}
late FirebaseFirestore firestore;
late String uid;
bool get = true;
late FirebaseAuth auth;
late String ps,v,ecg,rt,rh,bt;
class _DashboardState extends State<Dashboard> {
  var i = 0;

  @override
  void initState() {
    ps = '';
    v = '';
    ecg = '';
    rt = '';
    rh = '';
    bt = '';
    super.initState();
    firestore = FirebaseFirestore.instance;
    auth = FirebaseAuth.instance;
  }



  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    i = 0;
    get= true;
  }

  @override
  Widget build(BuildContext context) {

    if(get){
      FirebaseAuth.instance.authStateChanges().listen((User? user) {
        if (user != null) {
          getData(user.uid);
        }
      });
      get= false;
    }

    return WillPopScope(
      onWillPop: () async{
        if(i > 2){
          return true;
        }else{
          i++;
          return false;
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text('DASHBOARD'),),
        drawer: Drawer(
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the drawer if there isn't enough vertical
          // space to fit everything.
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
               Container(
                 height: 300,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  image: DecorationImage(
                    image: AssetImage('images/a_dot_ham.jpeg') ,
                      fit: BoxFit.fill
                  )
                ),
                child: Center(child: Text('Hi, Hiom User',style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),)),
              ),
              Container(
                height: MediaQuery.of(context).size.height-300,
                child: Stack(
                  children: [
                    Positioned(
                      bottom: 5,
                      left: 50,
                      child: Column(
                        children: [
                          GestureDetector(
                            onTap: (){
                              Navigator.of(context);
                              Navigator.of(context).pushNamed('/notification');
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                height: 50,
                                  width: 200,
                                  decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(25)
                                  ),
                                  child: const Center(child: Text('Notification',style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),),)),
                            ),
                          ),
                          GestureDetector(
                            onTap: (){
                              Navigator.of(context);
                              Navigator.of(context).pushNamed('/settings');
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                  height: 50,
                                  width: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.blue,
                                      borderRadius: BorderRadius.circular(25)
                                  ),
                                  child: const Center(child: Text('Settings',style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),),)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
        body: ListView(
          children: [
            Center(
              child: GridView.count(
                addAutomaticKeepAlives: false,
                crossAxisCount: 2,
                reverse: false,
                physics: const ClampingScrollPhysics(),
                shrinkWrap: true,
                children: [
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/result',arguments: {
                          'name':'$ps',
                          'color':Colors.blue,
                        });
                      }
                      ,child: Views().dashboard(context, Colors.blue,'Pulse Sensor',ps+ " HRM",Icons.sensors)),
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/chart',arguments: {
                          'name':v,
                          'icon':Icons.snowshoeing,
                          'color':Colors.blue,
                        });
                      },
                      child: Views().dashboard(context, Colors.blue,'Vibration',v+" metric units",Icons.vibration_outlined)),
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/views',arguments: {
                          'name':'$ecg',
                          'icon':Icons.waterfall_chart,
                          'color':Colors.blue,
                          'images':'images/glasses.png',

                        });
                      },
                      child: Views().dashboard(context, Colors.blue,'ECG',ecg+ " ampere",Icons.electrical_services,)),
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/views',arguments: {
                          'name':rt,
                          'icon':Icons.dining,
                          'color':Colors.blue,
                          'images':'images/dinner.png',
                        });
                      },
                      child: Views().dashboard(context, Colors.blue,'Room Temperature',rt+" degrees Celsius",Icons.meeting_room_outlined)),
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/views',arguments: {
                          'name':'Room Humidity',
                          'result':bt,
                          'icon':Icons.file_present,
                          'color':Colors.blue,
                        });
                      },
                      child: Views().dashboard(context, Colors.blue,'Room Humidity',rh+" relative humidity",Icons.room_preferences_outlined)),
                  GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushNamed('/views',arguments: {
                          'name':'Practical Work',
                          'result':bt,
                          'icon':Icons.collections_bookmark_sharp,
                          'color':Colors.blue,
                          'images':'images/read.png',
                        });
                      },
                      child: Views().dashboard(context, Colors.blue,'Body Temperature',bt+" degrees Celsius",Icons.sick)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  void getData(String value) async {
    print(value);
    FirebaseFirestore.instance
        .collection(value)
        .limit(1)
        .get()
        .then((QuerySnapshot querySnapshot) {
      for (var doc in querySnapshot.docs) {
        setState(() {
          ps = doc["ps"].toString();
          v = doc["v"].toString();
          ecg = doc["ecg"].toString();
          rt = doc["rt"].toString();
          rh = doc["rh"].toString();
          bt = doc["bt"].toString();
        });
      }
    });
  }
}
