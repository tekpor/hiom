import 'package:flutter/material.dart';
// import 'package:flutter_html/flutter_html.dart';

class Views{

  Widget dashboard(BuildContext context,Color c,String name,String time,IconData icons,{var anything}){

    return Padding(
      padding: const EdgeInsets.only(left: 8,right: 8,top: 5,bottom: 5),
      child: Container(
        height: 200,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: c,
        ),
        child: Stack(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: const [Padding(
                padding: EdgeInsets.all(8.0),
                child: Icon(Icons.more_vert_outlined,size: 30,),
              )],
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  anything !=null? Image.asset(anything,width: 100,height: 100,):Icon(icons,size: 100,color: Colors.white,),
                  Text(name,style: const TextStyle(fontSize: 25,fontWeight: FontWeight.normal,color: Colors.white),),
                  const SizedBox(height: 10,),
                  Text(time,style: const TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white),),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget notify(String text){
    return Padding(
      padding: const EdgeInsets.only(left: 8.0,right: 8,top: 4,bottom: 4),
      child: Container(
        clipBehavior: Clip.hardEdge,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.blue[800],
        ),
        child: Center(child: Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10,left: 10,right: 10),
          child: Text(text,style: const TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.white),),
        )),
      ),
    );
  }
  Widget appbar(BuildContext context){
    return SizedBox(
      height: 50,
      width: MediaQuery.of(context).size.width-100,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          GestureDetector(
            onTap: (){
              Navigator.of(context).pushReplacementNamed('/dashboard',arguments: {

              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.home_filled,color: Colors.black,size: 30,),
                Text('Home'),
              ],
            ),
          ),
          GestureDetector(
            onTap: (){
              Navigator.of(context).pushReplacementNamed('/notification',arguments: {

              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.notification_important,color: Colors.black,size: 30),
                Text('Notifications'),
              ],
            ),
          ),
          GestureDetector(
            onTap: (){
              Navigator.of(context).pushReplacementNamed('/explore',arguments: {

              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.star,color: Colors.black,size: 30),
                Text('Explore'),
              ],
            ),
          ),
          GestureDetector(
            onTap: (){
              Navigator.of(context).pushReplacementNamed('/profile',arguments: {
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.person,color: Colors.black,size: 30),
                Text('Profile'),
              ],
            ),
          ),
        ],
      ),

    );
  }

 Widget explore(BuildContext context,String text,String image) {
    return Padding(
      padding: const EdgeInsets.only(top: 4.0,bottom: 4,left: 8,right: 8),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15.0),
          color: Colors.blue[700],
        ),
        child: Wrap(
          children: [
            Container(
              height: 300,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.0),
                  color: Colors.blue[800],
                image: DecorationImage(
                  image: NetworkImage(image),
                  fit: BoxFit.fill
                )
              ),
    ),
          // Padding(
          //   padding: const EdgeInsets.all(8.0),
          //   child: Html(data:text.substring(0,text.length>300?300:text.length)),
          // ),
          ],
        ),
      ));
  }
}