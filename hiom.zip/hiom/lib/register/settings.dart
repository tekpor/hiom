import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ExitProfile extends StatefulWidget {
  const ExitProfile({Key? key}) : super(key: key);

  @override
  _ExitProfileState createState() => _ExitProfileState();
}
late FirebaseFirestore firestore;
late String uid;
late FirebaseAuth auth;
late String name,gender,phone,email,postal,res,profile;
class _ExitProfileState extends State<ExitProfile> {
  @override
  void initState() {
    name = '';
    gender = '';
    phone = '';
    email = '';
    postal = '';
    res = '';
    profile = '';
    super.initState();
    firestore = FirebaseFirestore.instance;
    auth = FirebaseAuth.instance;
  }

  @override
  Widget build(BuildContext context) {

    final AlertDialog withUs = AlertDialog(
      contentPadding: EdgeInsets.zero,
      content: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 50,
          height: 100,
          child:Column(
            children: const [
              CircularProgressIndicator(color: Colors.red,),
              Text("Processing... please wait!")
            ],
          ),
        ),
      ),
    );



    return Scaffold(
        floatingActionButton: GestureDetector(
            onTap: (){
              showDialog<void>(context: context, builder: (context) => withUs);
              getData(auth.currentUser!.uid,context);
            },
            child: const CircleAvatar(child: Icon(Icons.send_and_archive,size: 30,),radius: 25,)),
      body: ListView(
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 20.0,bottom: 4,top: 4),
            child: Icon(Icons.person,color: Colors.blue,size: 100,),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 15.0,right: 15),
            child: Text('Profile Picture:',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20.0),
            child: TextField(
              keyboardType: TextInputType.url,
              maxLines: 1,
              onChanged: (value){
                profile = value;
              },decoration: const InputDecoration(
              labelText: "Profile Picture URL:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Profile Picture URL:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20.0,top: 10),
            child: Text('Name:',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20.0),
            child: TextField(
              keyboardType: TextInputType.text,
              maxLines: 1,
              onChanged: (value){
                name = value;
              },decoration: const InputDecoration(
              labelText: "Name:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Name:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20.0,top: 10),
            child: Text('Gender:',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20.0),
            child: TextField(
              keyboardType: TextInputType.text,
              maxLines: 1,
              onChanged: (value){
                gender = value;
              },decoration: const InputDecoration(
              labelText: "Gender:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Gender:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),

          const Padding(
            padding: EdgeInsets.only(left: 10.0,bottom: 4,top: 4),
            child: Icon(Icons.contact_phone_outlined,color: Colors.blue,size: 100,),
          ),

          const Padding(
            padding: EdgeInsets.only(left: 20.0),
            child: Text('Phone Number:',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20.0,left: 20),
            child: TextField(
              keyboardType: TextInputType.phone,
              maxLines: 1,
              onChanged: (value){
                phone = value;
              },decoration: const InputDecoration(
              labelText: "Phone Number:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Phone Number:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20.0,top: 10),
            child: Text('Email:',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20.0,left: 20),
            child: TextField(
              keyboardType: TextInputType.emailAddress,
              maxLines: 1,
              onChanged: (value){
                email = value;
              },decoration: const InputDecoration(
              labelText: "Email:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Email:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),

          const Padding(
            padding: EdgeInsets.only(left: 10.0,bottom: 4,top: 4),
            child: Icon(Icons.location_on,color: Colors.blue,size: 100,),
          ),

          const Padding(
            padding: EdgeInsets.only(left: 20.0,top: 10),
            child: Text('Postal Address',style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20.0,left: 20),
            child: TextField(
              maxLines: 5,
              onChanged: (value){
                postal = value;
              },decoration: const InputDecoration(
              labelText: "Postal Address:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Postal Address:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20.0,top: 10),
            child: Text("Residential Address:",style: TextStyle(fontStyle: FontStyle.normal,fontSize: 20,color: Colors.black54),),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20.0,left: 20),
            child: TextField(
              maxLines: 5,
              onChanged: (value){
                res = value;
              },decoration: const InputDecoration(
              labelText: "Residential Address:",
              border: OutlineInputBorder(),
              helperStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              labelStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 15),
              hintText: 'Enter Your Residential Address:',
              hintStyle: TextStyle(fontStyle: FontStyle.normal,
                  fontWeight: FontWeight.normal,
                  color: Colors.blue,
                  fontSize: 20),
            ),),
          ),
          const SizedBox(height: 10,),
          SizedBox(height: 5,child: Container(
            color: Colors.black54,
          ),),
           const Center(child:Text('HIOM Version 1.0.1',style: TextStyle(fontStyle: FontStyle.normal,fontWeight: FontWeight.bold,fontSize: 32,color: Colors.deepPurple),), ),
        ],
      ),
    );
  }

  void getData(String id,BuildContext context){
    if(name.isNotEmpty &&gender.isNotEmpty){
      print(id);
      CollectionReference feed = FirebaseFirestore.instance.collection(id);
      feed.doc('profile').set({
        'profilepic': profile,
        'name': name,
        'gender': gender,
        'email': email,
        'phone': phone,
        'postal': postal,
        'res': res,
        'profile': 'yes',
      }).then((value) => {
        Navigator.pop(context),
        Navigator.pushReplacementNamed(context, '/profile',),
      }).onError((error, stackTrace) => {
        Navigator.pop(context),
        Navigator.pushReplacementNamed(context, '/profile',),
      });
    }else{
      Navigator.pop(context);
    Navigator.pushReplacementNamed(context, '/profile',);
    }
  }
}
