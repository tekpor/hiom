import 'package:flutter/material.dart';
import 'package:hiom/register/dashborad.dart';
import 'package:hiom/register/login.dart';
import 'package:hiom/register/notification.dart';
import 'package:hiom/register/register.dart';
import 'package:hiom/register/settings.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    routes: {
      '/':(context)=>const LogIn(),
       '/register':(context)=>const Register(),
      '/dashboard':(context)=>const Dashboard(),
      // '/result':(context)=>const Result(),
       '/notification':(context)=>const Notifications(),
      // '/explore':(context)=>const Explore(),
      // '/profile':(context)=>const Profile(),
      // '/explorereview':(context)=>const ExploreReview(),
      // '/chart':(context)=>const Chart(),
      // '/views':(context)=>const ListViewViews(),
       '/settings':(context)=>const ExitProfile(),
    },

  ));
}
